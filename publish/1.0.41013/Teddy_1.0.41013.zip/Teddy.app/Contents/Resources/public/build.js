TeddyGame = {alapAdatok: {howtoplayKepernyoVoltMar: 0,mennyiPontotGyujtottEppen: 0,mennyiCombotGyujtottEppen: 0,archik: {a1: {cim: "Collect 5 stars",kesz: 0},a2: {cim: "Make 5 combo in a row",kesz: 0},a3: {cim: "Collect 10 stars",kesz: 0},a4: {cim: "Collect 3 artifact",kesz: 0},a5: {cim: "Collect 20 stars",kesz: 0},a6: {cim: "Complete Fruity world",kesz: 0}},skill1HanyszorHasznalhato: 2,skill2HanyszorHasznalhato: 1,skill3HanyszorHasznalhato: 0,skill4HanyszorHasznalhato: 0,skill5HanyszorHasznalhato: 0,skill1PowerUpSzint: 1,skill2PowerUpSzint: 0,skill3PowerUpSzint: 0,skill4PowerUpSzint: 0,skill5PowerUpSzint: 0,mennyiCsillagotGyujtottOsszesen: 0,mennyiCsillagotKoltottOsszesen: 0,mennyiArtifaktotGyujtottOsszesen: 0,melyikVilagbanJatszikEppen: 1,melyikSzintenJatszikEppen: 1,vilagokEsSzintek: {vilag1: {vilagNeve: 'FRUITY WORLD',megnyertSzintek: 0,mennyiArtiKellAMegnyitashoz: 0,szint1: {letobbElertPont: 0,hanyfeleElemVan: 4,mennyitKellEltuntetnie: 150,mennyiIdejeVan: 100,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint2: {letobbElertPont: 0,hanyfeleElemVan: 4,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 110,mennyiCsillagotGyujthet: 3,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint3: {letobbElertPont: 0,hanyfeleElemVan: 4,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 110,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint4: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 100,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 0,mennyiArtifaktotGyujtott: 0},szint5: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 60,mennyiIdejeVan: 30,mennyiCsillagotGyujthet: 0,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint6: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 150,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint7: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 400,mennyiIdejeVan: 200,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint8: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 600,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 4,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint9: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 130,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint10: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 120,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint11: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 250,mennyiIdejeVan: 160,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint12: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 170,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint13: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 190,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint14: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 350,mennyiIdejeVan: 220,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint14: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 50,mennyiIdejeVan: 40,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint15: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 400,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint16: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint17: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint18: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 400,mennyiIdejeVan: 400,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint19: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 500,mennyiIdejeVan: 500,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint20: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 600,mennyiIdejeVan: 600,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0}},vilag2: {vilagNeve: 'SWEET WORLD',megnyertSzintek: 0,mennyiArtiKellAMegnyitashoz: 12,szint1: {letobbElertPont: 0,hanyfeleElemVan: 4,mennyitKellEltuntetnie: 150,mennyiIdejeVan: 100,mennyiCsillagotGyujthet: 3,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint2: {letobbElertPont: 0,hanyfeleElemVan: 4,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 110,mennyiCsillagotGyujthet: 4,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint3: {letobbElertPont: 0,hanyfeleElemVan: 3,mennyitKellEltuntetnie: 250,mennyiIdejeVan: 40,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint4: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 100,mennyiCsillagotGyujthet: 3,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 0,mennyiArtifaktotGyujtott: 0},szint5: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 30,mennyiIdejeVan: 25,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint6: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 150,mennyiCsillagotGyujthet: 3,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint7: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 400,mennyiIdejeVan: 200,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint8: {letobbElertPont: 0,hanyfeleElemVan: 5,mennyitKellEltuntetnie: 600,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 4,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint9: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 110,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint10: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 200,mennyiIdejeVan: 100,mennyiCsillagotGyujthet: 3,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 3,mennyiArtifaktotGyujtott: 0},szint11: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 250,mennyiIdejeVan: 120,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint12: {letobbElertPont: 0,hanyfeleElemVan: 6,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 170,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint13: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 190,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint14: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 350,mennyiIdejeVan: 210,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint14: {letobbElertPont: 0,hanyfeleElemVan: 7,mennyitKellEltuntetnie: 50,mennyiIdejeVan: 40,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint15: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 400,mennyiCsillagotGyujthet: 1,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 2,mennyiArtifaktotGyujtott: 0},szint16: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint17: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 300,mennyiIdejeVan: 300,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint18: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 400,mennyiIdejeVan: 400,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint19: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 500,mennyiIdejeVan: 500,mennyiCsillagotGyujthet: 2,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0},szint20: {letobbElertPont: 0,hanyfeleElemVan: 8,mennyitKellEltuntetnie: 600,mennyiIdejeVan: 600,mennyiCsillagotGyujthet: 8,mennyiCsillagotGyujtott: 0,mennyiArtifaktotGyujthet: 1,mennyiArtifaktotGyujtott: 0}}},asdmusic: null,asdorientated: false}};
TeddyGame.Boot = function(game) {
};
TeddyGame.Boot.prototype = {preload: function() {
        this.load.image('preloaderBackground', 'images/loading.png');
        this.load.image('preloaderBar', 'images/preload_progressbar.png')
    },getRatio: function(type, w, h) {
        var width = navigator.isCocoonJS ? window.innerWidth : 600;
        var height = navigator.isCocoonJS ? window.innerHeight : 1000;
        var scaleX = width / w, scaleY = height / h, result = {x: 1,y: 1};
        switch (type) {
            case 'all':
                result.x = scaleX > scaleY ? scaleY : scaleX;
                result.y = scaleX > scaleY ? scaleY : scaleX;
                break;
            case 'fit':
                result.x = scaleX > scaleY ? scaleX : scaleY;
                result.y = scaleX > scaleY ? scaleX : scaleY;
                break;
            case 'fill':
                result.x = scaleX;
                result.y = scaleY;
                break
        }
        return result
    },adatokMentese: function() {
        "use strict";
        localStorage.setItem("TeddyGamealapAdatok", JSON.stringify(TeddyGame.alapAdatok))
    },create: function() {
        if (localStorage.getItem("TeddyGamealapAdatok") === null) {
            localStorage.setItem("TeddyGamealapAdatok", JSON.stringify(TeddyGame.alapAdatok))
        } else {
            var retrievedObject = localStorage.getItem("TeddyGamealapAdatok");
            TeddyGame.alapAdatok = JSON.parse(retrievedObject)
        }
        this.game.input.maxPointers = 1;
        this.game.stage.disableVisibilityChange = false;
        var ratio = this.getRatio('all', 600, 1000);
        if (navigator.isCocoonJS) {
            this.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
            this.scale.pageAlignHorizontally = true;
            this.scale.pageAlignVeritcally = true;
            this.scale.maxWidth = 1536;
            this.scale.maxHeight = 2048;
            this.scale.minWidth = 260;
            this.scale.minHeight = 480;
            this.scale.setScreenSize(true)
        } else {
            this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            this.scale.pageAlignHorizontally = true;
            this.scale.pageAlignVertically = true;
            this.scale.setScreenSize(true);
            this.game.scale.refresh()
        }
        this.game.state.start('Preloader')
    },gameResized: function(width, height) {
    }};
TeddyGame.Preloader = function(game) {
    this.background = null;
    this.preloadBar = null;
    this.ready = false
};
TeddyGame.Preloader.prototype = {preload: function() {
        this.background = this.add.sprite(0, 0, 'preloaderBackground');
        this.preloadBar = this.add.sprite(70, 800, 'preloaderBar');
        this.load.setPreloadSprite(this.preloadBar);
        this.load.image('fomenuHatter2', 'images/fomenuHatter2.png');
        this.load.image('altalanosFejlec', 'images/altalanosFejlec.png');
        this.load.image('worldSelectCsuszka', 'images/worldSelectCsuszka.png');
        this.load.image('worldSelectHoljar', 'images/worldSelectHoljar.png');
        this.load.image('worldSelectPontokCont', 'images/worldSelectPontokCont.png');
        this.load.image('gombDuplaBalra', 'images/gombDuplaBalra.png');
        this.load.image('gombDuplaJobbra', 'images/gombDuplaJobbra.png');
        this.load.image('gombPlayIkon', 'images/gombPlayIkon2.png');
        this.load.image('vilag1Hatter', 'images/vilag1Hatter.png');
        this.load.image('vilag2Hatter', 'images/vilag2Hatter.png');
        this.load.image('vilagLockedHatter', 'images/vilagLockedHatter.png');
        this.load.image('fedoreteg', 'images/fedoreteg.png');
        this.load.image('altalanosHatter', 'images/altalanosHatter.png');
        this.load.image('fomenuGombPlay', 'images/fomenuGombPlay.png');
        this.load.image('fomenuGombContinue', 'images/fomenuGombContinue.png');
        this.load.image('fomenuGombArc', 'images/fomenuGombArc.png');
        this.load.image('fomenuGombMulti', 'images/fomenuGombMulti.png');
        this.load.image('fomenuGombPower', 'images/fomenuGombPower.png');
        this.load.atlas('vilag1Elemek', 'images/vilag1atlas.png', 'images/vilag1atlas.json');
        this.load.atlas('vilag2Elemek', 'images/vilag2atlas.png', 'images/vilag2atlas.json');
        this.load.image('skillGombZarva', 'images/skillGombZarva.png');
        this.load.image('skillGomb1', 'images/skillGomb1.png');
        this.load.image('skillGomb2', 'images/skillGomb2.png');
        this.load.image('skillGomb3', 'images/skillGomb3.png');
        this.load.image('skillGomb4', 'images/skillGomb4.png');
        this.load.image('skillGomb5', 'images/skillGomb5.png');
        this.load.image('gombKilep', 'images/gombKilep.png');
        this.load.image('gombBeallitasok', 'images/gombBeallitasok.png');
        this.load.image('gombVissza', 'images/gombVissza.png');
        this.load.image('gombIbetu', 'images/gombIbetu.png');
        //this.load.image('cubimal', 'images/cubimal.png');
        //this.load.image('cubimal2', 'images/cubimal2.png');
        this.load.bitmapFont('carter', 'fonts/carter.png', 'fonts/carter.json');
        this.load.image('ido_progressbar', 'images/ido_progressbar.png');
        this.load.image('sziv_progressbar', 'images/sziv_progressbar.png');
        this.load.image('jatekHatter', 'images/jatekHatter.png');
        this.load.image('star_particle', 'images/star_particle.png');
        this.load.spritesheet('eltunesAnim1', 'images/anims/effect_002.png', 48, 48);
        this.load.spritesheet('eltunesAnim2', 'images/anims/light_004.png', 48, 48);
        this.load.spritesheet('eltunesAnim3', 'images/anims/wind_002.png', 48, 48);
        this.load.spritesheet('eltunesAnim4', 'images/anims/darkness_002.png', 48, 48);
        this.load.spritesheet('egyebAnim1', 'images/anims/heal_001.png', 48, 48);
        this.load.spritesheet('egyebAnim2', 'images/anims/fire_001.png', 48, 48);
        this.load.spritesheet('comboAnim1', 'images/anims/slash_001.png', 192, 192);
        this.load.spritesheet('fomenuGombPlaySheet', 'images/fomenuGombPlaySheet.png', 217, 69);
        this.load.spritesheet('pillango', 'images/npc_batterfly__x1_front_waiting_png_1354831849.png', 111, 96);
        this.load.image('egyszintZarva', 'images/egyszintZarva.png');
        this.load.image('szintValasztoMennyitGyujtott1', 'images/szintValasztoMennyitGyujtott1.png');
        this.load.image('szintValasztoMennyitGyujtott2', 'images/szintValasztoMennyitGyujtott2.png');
        this.load.image('specialisElemCsillag', 'images/csillagElem.png');
        this.load.image('specialisElemArtifakt11', 'images/vilag1arifact1.png');
        this.load.image('gombPause', 'images/gombPause.png');
        this.load.spritesheet('egyszintNyitvaSprite', 'images/egyszintNyitvaSprite3.png', 112, 119);
        this.load.image('szintKeszKepernyoHatter', 'images/szintKeszKepernyoHatter.png');
        this.load.image('archiLocked', 'images/archiLocked.png');
        this.load.image('archiKesz', 'images/archiKesz.png');
        this.load.image('powerupHatter', 'images/powerupHatter.png');
        this.load.image('skillLockedHatter', 'images/skillLockedHatter.png');
        this.load.image('gombVasarlas', 'images/gombVasarlas.png');
        this.load.image('pausedHatter', 'images/pausedHatter.png');
        this.load.image('gombSargaMenu', 'images/gombSargaMenu.png');
        this.load.image('gombSargaPlay', 'images/gombSargaPlay.png');
        this.load.image('gombSargaRestart', 'images/gombSargaRestart.png');
        this.load.image('howtoplay', 'images/howtoplay.png');
        this.load.image('levelClearedHatter', 'images/levelClearedHatter.png');
        this.load.image('levelFailedHatter', 'images/levelFailedHatter.png');
        this.load.image('sugoNyilak', 'images/sugoNyilak.png');
        this.load.image('sugoNyilak2', 'images/sugoNyilak2.png');
        this.load.audio('titleMusic', ['audio/Curious_Critters2.mp3', 'audio/Curious_Critters2.ogg']);
        this.load.audio('taps', ['audio/taps.mp3', 'audio/taps.ogg']);
        this.load.audio('csillag', ['audio/csillag.mp3', 'audio/csillag.ogg']);
        this.load.audio('hangMenuClick', ['audio/MenuSelectionClick.mp3', 'audio/MenuSelectionClick.ogg']);
        this.load.audio('hangRobbanas', ['audio/explodemini.mp3', 'audio/explodemini.ogg']);
        this.load.audio('hangEltunes1', ['audio/eltunes1.mp3', 'audio/eltunes1.ogg']);
        this.load.audio('hangEltunes2', ['audio/eltunes2.mp3', 'audio/eltunes2.ogg']);
        this.load.audio('hangEltunes3', ['audio/eltunes3.mp3', 'audio/eltunes3.ogg']);
        this.load.audio('hangEsik1', ['audio/esik1.mp3', 'audio/esik1.ogg']);
        this.load.audio('negativ', ['audio/negative_2.mp3', 'audio/negative_2.ogg']);
        this.load.audio('click', ['audio/click.mp3', 'audio/click.ogg'])
    },create: function() {
        this.preloadBar.cropEnabled = false
    },update: function() {
        if (this.cache.isSoundDecoded('titleMusic') && this.ready == false) {
            this.ready = true;
            this.music = this.add.audio('titleMusic', 1, true);
            this.music.play('', 0, 1, true);
            this.game.state.start('MainMenu')
        }
    }};
TeddyGame.MainMenu = function(game) {
    this.music = null;
    this.playButton = null;
    this.fomenuGombArc
};
TeddyGame.MainMenu.prototype = {create: function() {
        this.add.sprite(0, 0, 'altalanosHatter');
        var fejlec = this.add.group();
        fejlec.alpha = 0;
        fejlec.y = -110;
        var fejlecHatter = this.add.sprite(110, 20, 'altalanosFejlec');
        var fejlecSzoveg = this.add.bitmapText(150, 15, 'carter', "MAIN MENU", 30);
        fejlec.add(fejlecHatter);
        fejlec.add(fejlecSzoveg);
        this.add.tween(fejlec).to({y: 0,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var fomenuHatter2 = this.add.sprite(-300, 155, 'fomenuHatter2');
        fomenuHatter2.alpha = 0;
        this.add.tween(fomenuHatter2).to({x: 93,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var fomenuGombPlay = this.add.button(500, 350, 'fomenuGombPlaySheet', this.worldSelectStart, this, 0, 0, 1);
        fomenuGombPlay.alpha = 0;
        this.add.tween(fomenuGombPlay).to({x: 190,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 200, 0, false);
        var fomenuGombContinue = this.add.button(500, 500, 'fomenuGombContinue', this.startGame, this, 0, 0, 1);
        fomenuGombContinue.alpha = 0;
        this.add.tween(fomenuGombContinue).to({x: 190,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 300, 0, false);
        var gombIbetu = this.add.button(450, 1000, 'gombIbetu', this.gombIbetuKlikk, this, 0, 0, 1);
        gombIbetu.alpha = 0;
        this.add.tween(gombIbetu).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 300, 0, false);
        var pillango = this.add.sprite(600, 700, 'pillango');
        pillango.animations.add('walk');
        pillango.animations.play('walk', 20, true);
        var tween = this.add.tween(pillango).to({x: 440,y: 810}, 3000, Phaser.Easing.Quadratic.InOut, false, 1000).to({x: 200,y: 670}, 2000, Phaser.Easing.Quadratic.InOut, false, 2000).to({x: 50,y: 810}, 3000, Phaser.Easing.Quadratic.InOut, false, 3000).to({x: 80,y: 80}, 6000, Phaser.Easing.Quadratic.InOut, false, 6000).loop().start();
        if (typeof TeddyGame.alapAdatok.cubimalPromo === 'undefined') {
        }
    },update: function() {
    },gombIbetuKlikk: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('About')
    },worldSelectStart: function(pointer) {
        this.sound.play('hangMenuClick');
        this.game.state.start('WorldSelect')
    },startGame: function(pointer) {
        this.sound.play('hangMenuClick');
        if (TeddyGame.alapAdatok.howtoplayKepernyoVoltMar == 0) {
            this.game.state.start('Howtoplay')
        } else {
            if (TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].megnyertSzintek < 20) {
                TeddyGame.alapAdatok.melyikSzintenJatszikEppen = (TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].megnyertSzintek) + 1
            } else {
            }
            this.game.state.start('Game')
        }
    },startPower: function(pointer) {
        this.sound.play('hangMenuClick');
        this.game.state.start('PowerUps')
    },startArc: function(pointer) {
        this.sound.play('hangMenuClick');
        this.game.state.start('Archievements')
    }};
TeddyGame.WorldSelect = function(game) {
    this.worldSelectHoljar;
    this.kivalasztottVilag = 1;
    this.worldLeiroKep;
    this.worldLeiroKep2;
    this.melyikWorldLeiroAktiv = 1;
    this.lehetLapozni = 1;
    this.worldSelectPontokCont;
    this.worldSelectPontokSzoveg;
    this.gombPlayIkon
};
TeddyGame.WorldSelect.prototype = {create: function() {
        this.kivalasztottVilag = 1;
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fejlec = this.add.group();
        fejlec.alpha = 0;
        fejlec.y = -110;
        var fejlecHatter = this.add.sprite(110, 20, 'altalanosFejlec');
        var fejlecSzoveg = this.add.bitmapText(150, 25, 'carter', "WORLD SELECT", 22);
        fejlec.add(fejlecHatter);
        fejlec.add(fejlecSzoveg);
        this.add.tween(fejlec).to({y: 0,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.worldLeiroKep = this.add.sprite(-500, 155, 'vilag1Hatter');
        this.worldLeiroKep.alpha = 0;
        this.add.tween(this.worldLeiroKep).to({x: 93,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.worldLeiroKep2 = this.add.sprite(1500, 155, 'fomenuHatter2');
        this.worldLeiroKep2.alpha = 0;
        var gombVissza = this.add.button(50, 1000, 'gombVissza', this.mainMenu, this, 0, 0, 1);
        gombVissza.alpha = 0;
        this.add.tween(gombVissza).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 100, 0, false);
        var worldSelectCsuszka = this.add.sprite(40, 1100, 'worldSelectCsuszka');
        worldSelectCsuszka.alpha = 0;
        worldSelectCsuszka.visible = false;
        this.add.tween(worldSelectCsuszka).to({y: 800,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 700, 0, false);
        this.worldSelectHoljar = this.add.sprite(32, 1100, 'worldSelectHoljar');
        this.worldSelectHoljar.alpha = 0;
        this.worldSelectHoljar.visible = false;
        this.add.tween(this.worldSelectHoljar).to({y: 798,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 700, 0, false);
        this.worldSelectPontokCont = this.add.sprite(190, 640, 'worldSelectPontokCont');
        this.worldSelectPontokCont.alpha = 0;
        this.add.tween(this.worldSelectPontokCont).to({alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 700, 0, false);
        this.worldSelectPontokSzoveg = this.add.bitmapText(270, 638, 'carter', "?/?", 22);
        this.worldSelectPontokSzoveg.alpha = 0;
        this.add.tween(this.worldSelectPontokSzoveg).to({alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 700, 0, false);
        this.worldSelectMennyiKellKilockhozSzoveg = this.add.bitmapText(150, 530, 'carter', "You need to collect \n 10 artifacts to unlock\n this world.", 14);
        this.worldSelectMennyiKellKilockhozSzoveg.visible = false;
        this.add.tween(this.worldSelectMennyiKellKilockhozSzoveg).to({alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 700, 0, false);
        this.gombPlayIkon = this.add.button(-500, 530, 'gombPlayIkon', this.playGombKlikk, this);
        this.gombPlayIkon.alpha = 0;
        this.add.tween(this.gombPlayIkon).to({x: 250,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var gombDuplaBalra = this.add.button(-100, 430, 'gombDuplaBalra', this.lapozBalra, this);
        gombDuplaBalra.alpha = 0;
        this.add.tween(gombDuplaBalra).to({x: 40,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 400, 0, false);
        var gombDuplaJobbra = this.add.button(600, 430, 'gombDuplaJobbra', this.lapozJobbra, this);
        gombDuplaJobbra.alpha = 0;
        this.add.tween(gombDuplaJobbra).to({x: 470,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 400, 0, false);
        this.mennyitGyujthet()
    },playGombKlikk: function() {
        this.sound.play('hangMenuClick');
        TeddyGame.alapAdatok.melyikVilagbanJatszikEppen = this.kivalasztottVilag;
        TeddyGame.Boot.prototype.adatokMentese();
        this.game.state.start('SzintValasztas')
    },vilagTexturaCsere: function(melyikre) {
        var textura = "vilagLockedHatter";
        if (this.kivalasztottVilag == 1) {
            textura = "vilag1Hatter"
        }
        if (this.kivalasztottVilag == 2) {
            textura = "vilag2Hatter"
        }
        if (textura == "vilagLockedHatter" || textura == "vilag2Hatter") {
            this.gombPlayIkon.visible = 0;
            this.gombPlayIkon.kill();
            this.worldSelectPontokCont.visible = 0;
            this.worldSelectPontokSzoveg.visible = 0
        } else {
            this.gombPlayIkon.visible = 1;
            this.worldSelectPontokCont.visible = 1;
            this.worldSelectPontokSzoveg.visible = 1
        }
        if (melyikre == 1) {
            this.worldLeiroKep.loadTexture(textura, 0)
        } else {
            this.worldLeiroKep2.loadTexture(textura, 0)
        }
        this.mennyitGyujthet()
    },mennyitGyujthet: function() {
        var mennyitGyujthet = 0;
        var mennyitGyujtott = 0;
        for (var index in TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + this.kivalasztottVilag]) {
            if (index != "vilagNeve" && index != "megnyertSzintek" && index != "mennyiArtiKellAMegnyitashoz") {
                var attr = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + this.kivalasztottVilag][index];
                mennyitGyujthet += attr.mennyiCsillagotGyujthet;
                mennyitGyujtott += attr.mennyiCsillagotGyujtott
            }
        }
        this.worldSelectPontokSzoveg.setText(mennyitGyujtott + "/" + mennyitGyujthet);
        if (this.kivalasztottVilag == 2) {
            var mennyitGyujthetArti = 0;
            var mennyitGyujtottArti = 0;
            for (var index in TeddyGame.alapAdatok.vilagokEsSzintek["vilag1"]) {
                if (index != "vilagNeve" && index != "megnyertSzintek" && index != "mennyiArtiKellAMegnyitashoz") {
                    var attr = TeddyGame.alapAdatok.vilagokEsSzintek["vilag1"][index];
                    mennyitGyujthetArti += attr.mennyiArtifaktotGyujthet;
                    mennyitGyujtottArti += attr.mennyiArtifaktotGyujtott
                }
            }
            if (mennyitGyujtottArti >= TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + this.kivalasztottVilag].mennyiArtiKellAMegnyitashoz) {
                this.worldSelectMennyiKellKilockhozSzoveg.visible = false;
                this.gombPlayIkon.visible = 1;
                this.worldSelectPontokCont.visible = 1;
                this.worldSelectPontokSzoveg.visible = 1
            } else {
                this.worldSelectMennyiKellKilockhozSzoveg.visible = true;
                this.worldSelectMennyiKellKilockhozSzoveg.setText("You need to collect \n " + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + this.kivalasztottVilag].mennyiArtiKellAMegnyitashoz + " artifacts to unlock\n this world.")
            }
        } else {
            this.worldSelectMennyiKellKilockhozSzoveg.visible = false
        }
    },lapozJobbra: function() {
        this.sound.play('hangMenuClick');
        if (this.lehetLapozni) {
            if (this.kivalasztottVilag < 2) {
                this.lehetLapozni = 0;
                this.kivalasztottVilag++;
                this.mennyitGyujthet();
                this.add.tween(this.worldSelectHoljar).to({x: (this.kivalasztottVilag * 52) - 17}, 300, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                if (this.melyikWorldLeiroAktiv == 1) {
                    this.vilagTexturaCsere(2);
                    var worldValtasAnim = this.add.tween(this.worldLeiroKep).to({x: -500,alpha: 0}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    this.worldLeiroKep2.x = 1500;
                    this.add.tween(this.worldLeiroKep2).to({x: 93,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    var that = this;
                    worldValtasAnim.onComplete.add(function() {
                        that.add.tween(that.worldSelectPontokCont).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.worldSelectPontokSzoveg).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.gombPlayIkon).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.worldLeiroKep.x = 1500;
                        that.melyikWorldLeiroAktiv = 2;
                        that.lehetLapozni = 1
                    })
                }
                if (this.melyikWorldLeiroAktiv == 2) {
                    this.vilagTexturaCsere(1);
                    var worldValtasAnim = this.add.tween(this.worldLeiroKep2).to({x: -500,alpha: 0}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    this.worldLeiroKep.x = 1500;
                    this.add.tween(this.worldLeiroKep).to({x: 93,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    var that = this;
                    worldValtasAnim.onComplete.add(function() {
                        that.add.tween(that.worldSelectPontokCont).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.worldSelectPontokSzoveg).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.gombPlayIkon).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.worldLeiroKep2.x = 1500;
                        that.melyikWorldLeiroAktiv = 1;
                        that.lehetLapozni = 1
                    })
                }
            }
        }
    },lapozBalra: function() {
        this.sound.play('hangMenuClick');
        if (this.lehetLapozni) {
            if (this.kivalasztottVilag > 1) {
                this.lehetLapozni = 0;
                this.kivalasztottVilag--;
                this.mennyitGyujthet();
                this.add.tween(this.worldSelectHoljar).to({x: (this.kivalasztottVilag * 52) - 17}, 300, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                if (this.melyikWorldLeiroAktiv == 1) {
                    this.vilagTexturaCsere(2);
                    var worldValtasAnim = this.add.tween(this.worldLeiroKep).to({x: 1500,alpha: 0}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    this.worldLeiroKep2.x = -500;
                    this.add.tween(this.worldLeiroKep2).to({x: 93,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    var that = this;
                    worldValtasAnim.onComplete.add(function() {
                        that.add.tween(that.worldSelectPontokCont).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.worldSelectPontokSzoveg).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.gombPlayIkon).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.worldLeiroKep.x = -500;
                        that.melyikWorldLeiroAktiv = 2;
                        that.lehetLapozni = 1
                    })
                }
                if (this.melyikWorldLeiroAktiv == 2) {
                    this.vilagTexturaCsere(1);
                    var worldValtasAnim = this.add.tween(this.worldLeiroKep2).to({x: 1500,alpha: 0}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    this.worldLeiroKep.x = -500;
                    this.add.tween(this.worldLeiroKep).to({x: 93,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                    var that = this;
                    worldValtasAnim.onComplete.add(function() {
                        that.add.tween(that.worldSelectPontokCont).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.worldSelectPontokSzoveg).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.add.tween(that.gombPlayIkon).to({alpha: 1}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                        that.worldLeiroKep2.x = -500;
                        that.melyikWorldLeiroAktiv = 1;
                        that.lehetLapozni = 1
                    })
                }
            }
        }
    },mainMenu: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },update: function() {
    },startGame: function(pointer) {
    }};
TeddyGame.SzintMegnyerve = function(game) {
    this.game;
    this.add;
    this.camera;
    this.cache;
    this.input;
    this.load;
    this.math;
    this.sound;
    this.stage;
    this.time;
    this.tweens;
    this.world;
    this.particles;
    this.physics;
    this.rnd;
    this.t1;
    this.pontPorgetesHolJar;
    this.jelenlegiPont
};
TeddyGame.SzintMegnyerve.prototype = {create: function() {
        this.sound.play('taps');
        console.log("szint megnyerve indul");
        this.pontPorgetesHolJar = 0;
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fomenuHatter2 = this.add.sprite(-300, 155, 'levelClearedHatter');
        fomenuHatter2.alpha = 0;
        this.add.tween(fomenuHatter2).to({x: 65,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var szovegek = this.add.group();
        szovegek.alpha = 0;
        szovegek.x = 1500;
        var legtobbElertPont = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].letobbElertPont;
        this.jelenlegiPont = TeddyGame.alapAdatok.mennyiPontotGyujtottEppen;
        var t0 = this.add.bitmapText(0, 270, 'carter', "Level " + TeddyGame.alapAdatok.melyikSzintenJatszikEppen + " cleared!", 23, szovegek);
        this.t1 = this.add.bitmapText(0, 310, 'carter', "Score: 0", 23, szovegek);
        var t2 = this.add.bitmapText(0, 350, 'carter', "Best score: " + legtobbElertPont, 23, szovegek);
        var t3 = this.add.bitmapText(0, 390, 'carter', "Combos: " + TeddyGame.alapAdatok.mennyiCombotGyujtottEppen, 23, szovegek);
        var t4 = this.add.bitmapText(0, 430, 'carter', "Stars: " + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujthet, 23, szovegek);
        var t5 = this.add.bitmapText(0, 470, 'carter', "Artifacts: " + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujthet, 23, szovegek);
        szovegek.add(this.t1);
        szovegek.add(t0);
        szovegek.add(t2);
        szovegek.add(t3);
        szovegek.add(t4);
        szovegek.add(t5);
        this.add.tween(szovegek).to({x: 110,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.gombSargaRestart = this.add.button(120, 620, 'gombSargaRestart', this.elolrolKezdes, this);
        this.gombSargaPlay = this.add.button(260, 620, 'gombSargaPlay', this.szintNemSikerultTovabbKlikk, this);
        this.gombSargaMenu = this.add.button(400, 620, 'gombSargaMenu', this.menube, this)
    },elolrolKezdes: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('Game')
    },szintNemSikerultTovabbKlikk: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('SzintValasztas')
    },menube: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },update: function() {
        if (this.pontPorgetesHolJar < this.jelenlegiPont) {
            if (this.pontPorgetesHolJar + 100 > this.jelenlegiPont) {
                this.pontPorgetesHolJar = this.jelenlegiPont
            } else {
                this.pontPorgetesHolJar += 100
            }
            this.t1.setText("Score: " + this.pontPorgetesHolJar)
        }
    },startGame: function(pointer) {
    }};
TeddyGame.SzintNemSikerult = function(game) {
    this.t1;
    this.pontPorgetesHolJar;
    this.jelenlegiPont
};
TeddyGame.SzintNemSikerult.prototype = {create: function() {
        console.log("szint megnyerve indul");
        this.pontPorgetesHolJar = 0;
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fomenuHatter2 = this.add.sprite(-300, 155, 'levelFailedHatter');
        fomenuHatter2.alpha = 0;
        this.add.tween(fomenuHatter2).to({x: 65,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var szovegek = this.add.group();
        szovegek.alpha = 0;
        szovegek.x = 1500;
        var legtobbElertPont = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].letobbElertPont;
        this.jelenlegiPont = TeddyGame.alapAdatok.mennyiPontotGyujtottEppen;
        this.t1 = this.add.bitmapText(0, 270, 'carter', "Score: 0", 23, szovegek);
        var t2 = this.add.bitmapText(0, 310, 'carter', "Best score: " + legtobbElertPont, 23, szovegek);
        var t3 = this.add.bitmapText(0, 350, 'carter', "Combos: " + TeddyGame.alapAdatok.mennyiCombotGyujtottEppen, 23, szovegek);
        var t4 = this.add.bitmapText(0, 390, 'carter', "Stars: " + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujthet, 23, szovegek);
        var t5 = this.add.bitmapText(0, 430, 'carter', "Artifacts: " + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujthet, 23, szovegek);
        szovegek.add(this.t1);
        szovegek.add(t2);
        szovegek.add(t3);
        szovegek.add(t4);
        szovegek.add(t5);
        this.add.tween(szovegek).to({x: 120,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.gombSargaRestart = this.add.button(120, 620, 'gombSargaRestart', this.elolrolKezdes, this);
        this.gombSargaPlay = this.add.button(260, 620, 'gombSargaPlay', this.szintNemSikerultTovabbKlikk, this);
        this.gombSargaMenu = this.add.button(400, 620, 'gombSargaMenu', this.menube, this)
    },elolrolKezdes: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('Game')
    },szintNemSikerultTovabbKlikk: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('SzintValasztas')
    },menube: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },update: function() {
        if (this.pontPorgetesHolJar < this.jelenlegiPont) {
            if (this.pontPorgetesHolJar + 100 > this.jelenlegiPont) {
                this.pontPorgetesHolJar = this.jelenlegiPont
            } else {
                this.pontPorgetesHolJar += 100
            }
            this.t1.setText("Score: " + this.pontPorgetesHolJar)
        }
    }};
TeddyGame.SzintValasztas = function(game) {
};
TeddyGame.SzintValasztas.prototype = {create: function() {
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var vilagneve = this.add.bitmapText(40, -10, 'carter', TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].vilagNeve, 26);
        var megnyertSzintek = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].megnyertSzintek;
        var frame = 0;
        for (var y = 0; y <= 4; y++) {
            for (var x = 0; x <= 3; x++) {
                var szint = (frame + 1);
                var holAHelyeX = 40 + (x * 135);
                var holAHelyeY = 120 + (y * 155);
                if (megnyertSzintek + 1 < szint) {
                    var egy = this.add.sprite(1000, holAHelyeY, 'egyszintZarva')
                } else {
                    var egy = this.add.sprite(1000, holAHelyeY, 'egyszintNyitvaSprite');
                    egy.frame = frame;
                    egy.szint = szint;
                    egy.inputEnabled = true;
                    egy.events.onInputDown.add(this.elemreKattint, egy);
                    egy.alpha = 0;
                    var szintValasztoMennyitGyujtott1 = this.add.sprite(holAHelyeX + 10, holAHelyeY - 10, 'szintValasztoMennyitGyujtott1');
                    var szintValasztoMennyitGyujtott2 = this.add.sprite(holAHelyeX + 10, holAHelyeY + 85, 'szintValasztoMennyitGyujtott2');
                    szintValasztoMennyitGyujtott1.alpha = 0;
                    szintValasztoMennyitGyujtott2.alpha = 0;
                    var szoveg = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + szint].mennyiCsillagotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + szint].mennyiCsillagotGyujthet;
                    var szoveg1 = this.add.bitmapText(holAHelyeX + 48, holAHelyeY - 10, 'carter', szoveg, 11);
                    szoveg1.alpha = 0;
                    var szoveg = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + szint].mennyiArtifaktotGyujtott + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + szint].mennyiArtifaktotGyujthet;
                    var szoveg2 = this.add.bitmapText(holAHelyeX + 48, holAHelyeY + 86, 'carter', szoveg, 11);
                    szoveg2.alpha = 0;
                    this.add.tween(szintValasztoMennyitGyujtott1).to({alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 700 + (szint * 30), 0, false);
                    this.add.tween(szintValasztoMennyitGyujtott2).to({alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 700 + (szint * 30), 0, false);
                    this.add.tween(szoveg1).to({alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 700 + (szint * 30), 0, false);
                    this.add.tween(szoveg2).to({alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 700 + (szint * 30), 0, false)
                }
                this.add.tween(egy).to({x: holAHelyeX,alpha: 1}, 700, Phaser.Easing.Quadratic.Out, true, holAHelyeX / 2, 0, false);
                frame++
            }
        }
        var gombVissza = this.add.button(50, 1000, 'gombVissza', this.visszGombKlikk, this, 0, 0, 1);
        gombVissza.alpha = 0;
        this.add.tween(gombVissza).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 100, 0, false)
    },visszGombKlikk: function() {
        this.game.state.start('WorldSelect')
    },elemreKattint: function() {
        TeddyGame.alapAdatok.melyikSzintenJatszikEppen = this.szint;
        TeddyGame.Boot.prototype.adatokMentese();
        this.game.sound.play('hangMenuClick');
        if (TeddyGame.alapAdatok.howtoplayKepernyoVoltMar == 0) {
            this.game.state.start('Howtoplay')
        } else {
            this.game.state.start('Game')
        }
    },update: function() {
    },startGame: function(pointer) {
    }};
TeddyGame.Archievements = function(game) {
    this.worldSelectHoljar;
    this.kivalasztottVilag = 1;
    this.worldLeiroKep;
    this.worldLeiroKep2;
    this.melyikWorldLeiroAktiv = 1;
    this.lehetLapozni = 1;
    this.worldSelectPontokCont;
    this.worldSelectPontokSzoveg;
    this.gombPlayIkon;
    this.gombLenyomva = 0;
    this.gombLenyomvaY = 0;
    this.gombFelengedve = 0;
    this.gombFelengedveY = 0;
    this.archiCont
};
TeddyGame.Archievements.prototype = {create: function() {
        this.kivalasztottVilag = 1;
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fejlec = this.add.group();
        fejlec.alpha = 0;
        fejlec.y = -110;
        var fejlecHatter = this.add.sprite(110, 20, 'altalanosFejlec');
        var fejlecSzoveg = this.add.bitmapText(150, 30, 'carter', "ARCHIEVEMENTS", 20);
        fejlec.add(fejlecHatter);
        fejlec.add(fejlecSzoveg);
        this.add.tween(fejlec).to({y: 0,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.archiCont = this.add.group();
        var y = 150;
        var delay = 0;
        for (var index in TeddyGame.alapAdatok.archik) {
            var attr = TeddyGame.alapAdatok.archik[index];
            if (attr.kesz == 0) {
                var a = this.add.sprite(1000, y, 'archiLocked')
            } else {
                var a = this.add.sprite(1000, y, 'archiKesz')
            }
            var at = this.add.bitmapText(1000, y + 20, 'carter', attr.cim, 16);
            this.archiCont.add(a);
            this.archiCont.add(at);
            this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, delay, 0, false);
            this.add.tween(at).to({x: 160}, 200, Phaser.Easing.Quadratic.Out, true, delay + 100, 0, false);
            y += 110;
            delay += 200
        }
        var gombVissza = this.add.button(50, 1000, 'gombVissza', this.mainMenu, this, 0, 0, 1);
        gombVissza.alpha = 0;
        this.add.tween(gombVissza).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 100, 0, false)
    },mainMenu: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },swipeFel: function() {
    },swipeLe: function() {
    },update: function() {
        if (this.input.pointer1.isDown) {
            if (this.gombLenyomva == 0) {
                console.log('lenyomva');
                this.gombLenyomva = 1;
                this.gombLenyomvaY = this.input.pointer1.y
            }
        }
        if (this.gombLenyomva == 1) {
            if (this.input.pointer1.isUp) {
                console.log('up');
                this.gombLenyomva = 0;
                if (this.gombLenyomvaY + 100 < this.input.pointer1.y) {
                    this.swipeLe()
                }
                if (this.gombLenyomvaY - 100 > this.input.pointer1.y) {
                    this.swipeFel()
                }
            }
        }
    }};
TeddyGame.PowerUps = function(game) {
    this.worldSelectHoljar;
    this.kivalasztottVilag = 1;
    this.worldLeiroKep;
    this.worldLeiroKep2;
    this.melyikWorldLeiroAktiv = 1;
    this.lehetLapozni = 1;
    this.worldSelectPontokCont;
    this.worldSelectPontokSzoveg;
    this.gombPlayIkon;
    this.mennyibolVasarolhat;
    this.skill1SzintSzoveg;
    this.mennyibolVasarolhatSzoveg
};
TeddyGame.PowerUps.prototype = {create: function() {
        this.mennyibolVasarolhat = TeddyGame.alapAdatok.mennyiCsillagotGyujtottOsszesen - TeddyGame.alapAdatok.mennyiCsillagotKoltottOsszesen;
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fejlec = this.add.group();
        fejlec.alpha = 0;
        fejlec.y = -110;
        var fejlecHatter = this.add.sprite(110, 20, 'altalanosFejlec');
        var fejlecSzoveg = this.add.bitmapText(150, 20, 'carter', "POWER-UPS", 28);
        fejlec.add(fejlecHatter);
        fejlec.add(fejlecSzoveg);
        this.add.tween(fejlec).to({y: 0,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.mennyibolVasarolhatSzoveg = this.add.bitmapText(180, 940, 'carter', "Available stars: " + this.mennyibolVasarolhat, 20);
        var a = this.add.sprite(1000, 150, 'powerupHatter');
        var a2 = this.add.sprite(-200, 163, 'skillGomb3');
        var at2 = this.add.bitmapText(1000, 155, 'carter', "Increasing number of bombs by 1", 11);
        this.skill1SzintSzoveg = this.add.bitmapText(1000, 190, 'carter', "Current level: " + TeddyGame.alapAdatok.skill1PowerUpSzint, 14);
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.add.tween(a2).to({x: 75}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.add.tween(at2).to({x: 160}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.add.tween(this.skill1SzintSzoveg).to({x: 160}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        this.add.button(430, 193, 'gombVasarlas', this.skill1Vasarlas, this, 0, 0, 1);
        var at3 = this.add.bitmapText(475, 185, 'carter', "5", 16);
        var a = this.add.sprite(1000, 260, 'skillLockedHatter');
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var a = this.add.sprite(1000, 370, 'skillLockedHatter');
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var a = this.add.sprite(1000, 480, 'skillLockedHatter');
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var a = this.add.sprite(1000, 590, 'skillLockedHatter');
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var a = this.add.sprite(1000, 700, 'skillLockedHatter');
        this.add.tween(a).to({x: 60}, 200, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var gombVissza = this.add.button(50, 1000, 'gombVissza', this.mainMenu, this, 0, 0, 1);
        gombVissza.alpha = 0;
        this.add.tween(gombVissza).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 100, 0, false)
    },skill1Vasarlas: function() {
        if (this.mennyibolVasarolhat >= 5) {
            this.sound.play('hangMenuClick');
            TeddyGame.alapAdatok.skill1HanyszorHasznalhato += 1;
            TeddyGame.alapAdatok.skill1PowerUpSzint += 1;
            TeddyGame.alapAdatok.mennyiCsillagotKoltottOsszesen += 5;
            this.mennyibolVasarolhat -= 5;
            this.skill1SzintSzoveg.setText("Current level: " + TeddyGame.alapAdatok.skill1PowerUpSzint);
            this.mennyibolVasarolhatSzoveg.setText("Available stars: " + (this.mennyibolVasarolhat));
            TeddyGame.Boot.prototype.adatokMentese()
        } else {
            this.sound.play('negativ')
        }
    },mainMenu: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },update: function() {
    }};
TeddyGame.Howtoplay = function(game) {
    this.game;
    this.add;
    this.camera;
    this.cache;
    this.input;
    this.load;
    this.math;
    this.sound;
    this.stage;
    this.time;
    this.tweens;
    this.world;
    this.particles;
    this.physics;
    this.rnd;
    this.worldSelectHoljar;
    this.kivalasztottVilag;
    this.worldLeiroKep;
    this.worldLeiroKep2;
    this.melyikWorldLeiroAktiv;
    this.lehetLapozni;
    this.worldSelectPontokCont;
    this.worldSelectPontokSzoveg;
    this.gombPlayIkon
};
TeddyGame.Howtoplay.prototype = {create: function() {
        var fomenuHatter = this.add.sprite(0, 0, 'howtoplay');
        fomenuHatter.width = 600;
        fomenuHatter.height = 1000;
        var fomenuGombPlay = this.add.button(190, 810, 'fomenuGombContinue', this.howtoPlaycontinueGomb, this)
    },howtoPlaycontinueGomb: function() {
        TeddyGame.alapAdatok.howtoplayKepernyoVoltMar = 1;
        TeddyGame.Boot.prototype.adatokMentese();
        this.sound.play('hangMenuClick');
        this.game.state.start('Game')
    },update: function() {
    },startGame: function(pointer) {
    }};
TeddyGame.About = function(game) {
    this.worldSelectHoljar;
    this.kivalasztottVilag = 1;
    this.worldLeiroKep;
    this.worldLeiroKep2;
    this.melyikWorldLeiroAktiv = 1;
    this.lehetLapozni = 1;
    this.worldSelectPontokCont;
    this.worldSelectPontokSzoveg;
    this.gombPlayIkon;
    this.mennyibolVasarolhat;
    this.skill1SzintSzoveg;
    this.mennyibolVasarolhatSzoveg
};
TeddyGame.About.prototype = {create: function() {
        var fomenuHatter = this.add.sprite(0, 0, 'altalanosHatter');
        var fejlec = this.add.group();
        fejlec.alpha = 0;
        fejlec.y = -110;
        var fejlecHatter = this.add.sprite(110, 20, 'altalanosFejlec');
        var fejlecSzoveg = this.add.bitmapText(205, 13, 'carter', "ABOUT", 32);
        fejlec.add(fejlecHatter);
        fejlec.add(fejlecSzoveg);
        this.add.tween(fejlec).to({y: 0,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var aboutStr = "";
        try{
        	aboutStr = "Version: " + BS.b$.App.getAppVersion() + " \n\n";
            aboutStr +="Programming: jetiny\n\n";
            aboutStr +="Music by Ian, Geddtd\n\n";
        }catch(e){}
        var aboutSzoveg = this.add.bitmapText(1000, 150, 'carter', aboutStr, 20);
        this.add.tween(aboutSzoveg).to({x: 40,alpha: 1}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
        var gombVissza = this.add.button(50, 1000, 'gombVissza', this.mainMenu, this, 0, 0, 1);
        gombVissza.alpha = 0;
        this.add.tween(gombVissza).to({y: 880,alpha: 1}, 400, Phaser.Easing.Quadratic.Out, true, 100, 0, false)
    },mainMenu: function() {
        this.sound.play('hangMenuClick');
        this.game.state.start('MainMenu')
    },update: function() {
    }};
TeddyGame.Game = function(game) {
    this.game;
    this.add;
    this.camera;
    this.cache;
    this.input;
    this.load;
    this.math;
    this.sound;
    this.stage;
    this.time;
    this.tweens;
    this.world;
    this.particles;
    this.physics;
    this.rnd;
    this.vizszintesDarab = 7;
    this.fuggolegesDarab = 8;
    this.elemSzelesseg = 82;
    this.elemMagassag = 82;
    this.hatterLayer;
    this.hanyadikElem;
    this.kivalasztottElemAnim;
    this.csillagok;
    this.cursors;
    this.apple;
    this.elemek;
    this.kivalasztott_elem_1;
    this.kivalasztott_elem_1_tween;
    this.kivalasztott_elem_2;
    this.kivalasztott_elem_2_tween;
    this.elemekGroup;
    this.scoreSzoveg;
    this.score;
    this.csillagSzoveg;
    this.csillag;
    this.csillagMennyiVanKint;
    this.artifaktSzoveg;
    this.artifakt;
    this.artifaktMennyiVanKint;
    this.emitter;
    this.lehetValasztani;
    this.hanyatKellTorolni;
    this.explosions;
    this.explosions2;
    this.explosions3;
    this.explosions4;
    this.egyebAnim1;
    this.egyebAnim2;
    this.comboNagyAnim;
    this.comboSzoveg;
    this.combok;
    this.combokOsszesen;
    this.comboEltunikAnim;
    this.idoTime;
    this.ido_progressbar;
    this.sziv_progressbar;
    this.mennyiIdejeVan;
    this.mennyitKellEltuntetnie;
    this.mennyitTuntetettEl;
    this.szintMegnyerve;
    this.szintMegnyerveTovabb;
    this.szintNemSikerult;
    this.skillGomb1;
    this.skillGomb2;
    this.skill1HanyszorHasznalva;
    this.skill2HanyszorHasznalva;
    this.skill1DarabSzoveg;
    this.skill2DarabSzoveg;
    this.pausedHatter;
    this.megallitva;
    this.fedoreteg;
    this.gombSargaPlay;
    this.gombSargaRestart;
    this.gombSargaMenu;
    this.miotaNemTudottLepniTimer;
    this.sugoMennyiIdoMulva = Phaser.Timer.SECOND * 12;
    this.sugoGrafika;
    this.sugoGrafika2
};
TeddyGame.Game.prototype = {shutdown: function() {
        this.time.events.remove(this.miotaNemTudottLepniTimer)
    },create: function() {
        this.hangMenuClick = this.game.add.audio('hangMenuClick', 0.7);
        this.hangEltunes1 = this.game.add.audio('hangEltunes1', 0.7);
        this.hangEltunes2 = this.game.add.audio('hangEltunes2', 1);
        this.hangEltunes3 = this.game.add.audio('hangEltunes3', 1);
        this.miotaNemTudottLepniTimer = this.time.events.add(this.sugoMennyiIdoMulva, this.nemTudottLepni, this);
        this.hanyadikElem = 0;
        this.skill1HanyszorHasznalva = 0;
        this.skill2HanyszorHasznalva = 0;
        this.kivalasztottElemAnim = "";
        this.elemek = {};
        this.kivalasztott_elem_1 = "";
        this.kivalasztott_elem_2 = "";
        this.score = 0;
        this.lehetValasztani = 0;
        this.hanyatKellTorolni = 0;
        this.combok = 0;
        this.combokOsszesen = 0;
        this.comboEltunikAnim = "";
        this.idoTime = 0;
        this.csillag = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujtott;
        this.csillagMennyiVanKint = 0;
        this.artifakt = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujtott;
        this.artifaktMennyiVanKint = 0;
        this.mennyiIdejeVan = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiIdejeVan;
        this.mennyitKellEltuntetnie = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyitKellEltuntetnie;
        this.mennyitTuntetettEl = 0;
        this.szintMegnyerve = false;
        this.szintMegnyerveTovabb = false;
        this.szintNemSikerult = false;
        this.hatterLayer = this.add.group();
        this.hatterLayer.z = 1;
        var item = this.hatterLayer.create(0, 0, 'jatekHatter');
        item.width = 600;
        item.height = 1000;
        var pausegomb = this.add.button(535, 12, 'gombPause', this.pauseGomb, this, 0, 0, 1);
        pausegomb.width = 65;
        pausegomb.height = 65;
        this.elemekGroup = this.add.group();
        this.elemekGroup.x = 30;
        this.elemekGroup.y = 208;
        this.elemekGroup.z = 2;
        this.scoreSzoveg = this.add.bitmapText(126, 0, 'carter', "0", 20);
        this.csillagSzoveg = this.add.bitmapText(333, 7, 'carter', this.csillag + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujthet, 14);
        this.artifaktSzoveg = this.add.bitmapText(473, 7, 'carter', this.artifakt + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujthet, 14);
        for (var x = 0; x < this.vizszintesDarab; x++) {
            this.elemek[x] = {};
            for (var y = 0; y < this.fuggolegesDarab; y++) {
                this.ujElem(x, y, 1)
            }
        }
        var that = this;
        setTimeout(function() {
            that.pusztitasraJelolV2();
            that.pusztitKonkret()
        }, 1000);
        this.explosions = this.add.group();
        this.explosions2 = this.add.group();
        this.explosions3 = this.add.group();
        this.explosions4 = this.add.group();
        this.elemekGroup.add(this.explosions);
        this.elemekGroup.add(this.explosions2);
        this.elemekGroup.add(this.explosions3);
        this.elemekGroup.add(this.explosions4);
        this.explosions.createMultiple(30, 'eltunesAnim1');
        this.explosions2.createMultiple(30, 'eltunesAnim2');
        this.explosions3.createMultiple(30, 'eltunesAnim3');
        this.explosions4.createMultiple(30, 'eltunesAnim4');
        this.egyebAnim1 = this.add.sprite(50, 200, 'egyebAnim1');
        this.egyebAnim1.kill();
        this.egyebAnim2 = this.add.sprite(50, 200, 'egyebAnim2');
        this.egyebAnim2.kill();
        this.comboNagyAnim = this.add.sprite(50, 200, 'comboAnim1');
        this.comboNagyAnim.kill();
        this.skillGomb2 = this.add.button(360, 895, 'skillGomb1', this.skillHaszanalatEgyikElemEltuntetese, this);
        this.skillGomb1 = this.add.button(460, 895, 'skillGomb3', this.skillHaszanalatRobbantasKozepen, this);
        this.skill2DarabSzoveg = this.add.bitmapText(393, 955, 'carter', "" + TeddyGame.alapAdatok.skill2HanyszorHasznalhato, 13);
        this.skill1DarabSzoveg = this.add.bitmapText(493, 955, 'carter', "" + TeddyGame.alapAdatok.skill1HanyszorHasznalhato, 13);
        this.comboSzoveg = this.add.bitmapText(150, 250, 'carter', 'COMBO 2x', 30);
        this.comboSzoveg.visible = 0;
        this.comboSzoveg.alpha = 0;
        this.ido_progressbar = this.add.sprite(93, 150, 'ido_progressbar');
        this.ido_progressbar.height = 25;
        this.ido_progressbar.width = 450;
        this.sziv_progressbar = this.add.sprite(93, 106, 'sziv_progressbar');
        this.sziv_progressbar.height = 25;
        this.sziv_progressbar.width = 0;
        this.add.bitmapText(170, 138, 'carter', TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].vilagNeve + " Level " + TeddyGame.alapAdatok.melyikSzintenJatszikEppen, 14);
        this.megallitva = 0;
        this.sugoGrafika = this.add.sprite(120, 620, 'sugoNyilak');
        this.sugoGrafika.kill();
        this.sugoGrafika2 = this.add.sprite(120, 620, 'sugoNyilak2');
        this.sugoGrafika2.kill();
        this.elemekGroup.add(this.sugoGrafika);
        this.elemekGroup.add(this.sugoGrafika2)
    },vanEErvenyesLepes: function() {
        var masolat;
        var valasz = {talalat: false,lepes1: "",lepes2: ""};
        for (var x = 0; x < this.vizszintesDarab - 1; x++) {
            for (var y = 0; y < this.fuggolegesDarab; y++) {
                var masolat = {};
                for (var xx = 0; xx < this.vizszintesDarab; xx++) {
                    masolat[xx] = {};
                    for (var yy = 0; yy < this.fuggolegesDarab; yy++) {
                        masolat[xx][yy] = Object.create(this.elemek[xx][yy])
                    }
                }
                masolat[x][y] = this.elemek[x + 1][y];
                masolat[x + 1][y] = this.elemek[x][y];
                if (this.vanEPusztithato(masolat)) {
                    valasz.talalat = true;
                    valasz.lepes1 = this.elemek[x][y];
                    valasz.lepes2 = this.elemek[x + 1][y];
                    return valasz
                }
            }
        }
        for (var x = 0; x < this.vizszintesDarab; x++) {
            for (var y = 0; y < this.fuggolegesDarab - 1; y++) {
                var masolat = {};
                for (var xx = 0; xx < this.vizszintesDarab; xx++) {
                    masolat[xx] = {};
                    for (var yy = 0; yy < this.fuggolegesDarab; yy++) {
                        masolat[xx][yy] = Object.create(this.elemek[xx][yy])
                    }
                }
                masolat[x][y] = this.elemek[x][y + 1];
                masolat[x][y + 1] = this.elemek[x][y];
                if (this.vanEPusztithato(masolat)) {
                    valasz.talalat = true;
                    valasz.lepes1 = this.elemek[x][y];
                    valasz.lepes2 = this.elemek[x][y + 1];
                    return valasz
                }
            }
        }
        return valasz
    },vanEPusztithato: function(tabla) {
        var consecutive_symbols = 0;
        for (var y = 0; y < this.fuggolegesDarab; y++) {
            consecutive_symbols = 0;
            for (var x = 0; x < this.vizszintesDarab - 1; x++) {
                if (tabla[x][y].melyik_sprite == tabla[x + 1][y].melyik_sprite) {
                    consecutive_symbols++
                } else {
                    consecutive_symbols = 0
                }
                if (consecutive_symbols >= 2) {
                    return true
                }
            }
        }
        for (var x = 0; x < this.vizszintesDarab; x++) {
            consecutive_symbols = 0;
            for (var y = 0; y < this.fuggolegesDarab - 1; y++) {
                if (tabla[x][y].melyik_sprite == tabla[x][y + 1].melyik_sprite) {
                    consecutive_symbols++
                } else {
                    consecutive_symbols = 0
                }
                if (consecutive_symbols >= 2) {
                    return true
                }
            }
        }
        return false
    },nemTudottLepni: function() {
        var valasz = this.vanEErvenyesLepes();
        if (valasz.talalat) {
            if (valasz.lepes1.elemekX == valasz.lepes2.elemekX) {
                this.sugoGrafika2.revive();
                this.sugoGrafika2.bringToTop();
                this.sugoGrafika2.x = valasz.lepes1.x - 15;
                this.sugoGrafika2.y = valasz.lepes1.y + 5
            } else {
                this.sugoGrafika.revive();
                this.sugoGrafika.bringToTop();
                this.sugoGrafika.x = valasz.lepes1.x;
                this.sugoGrafika.y = valasz.lepes1.y - 15
            }
        } else {
            TeddyGame.alapAdatok.skill2HanyszorHasznalhato++;
            this.skillHaszanalatEgyikElemEltuntetese();
            this.miotaNemTudottLepniTimer = this.time.events.add(this.sugoMennyiIdoMulva, this.nemTudottLepni, this)
        }
    },inputNyomva: function() {
        console.log(this.input);
        console.log(this.input.x)
    },inputElengedve: function() {
        console.log(this.input);
        console.log(this.input.x);
        if (this.lehetValasztani == 1) {
            if (this.kivalasztott_elem_1 != "") {
                console.log(this.kivalasztott_elem_1.x);
                console.log(this.kivalasztott_elem_1.y)
            }
        }
    },pauseGomb: function() {
        if (this.megallitva == 0 && this.szintMegnyerve == 0) {
            this.lehetValasztani = 0;
            this.megallitva = 1;
            this.fedoreteg = this.add.sprite(0, 0, 'fedoreteg');
            this.fedoreteg.width = 600;
            this.fedoreteg.height = 1000;
            this.fedoreteg.alpha = 0.7;
            this.pausedHatter = this.add.sprite(100, 250, 'pausedHatter');
            this.gombSargaPlay = this.add.button(135, 320, 'gombSargaPlay', this.pauseVege, this);
            this.gombSargaRestart = this.add.button(255, 320, 'gombSargaRestart', this.elolrolKezdes, this);
            this.gombSargaMenu = this.add.button(375, 320, 'gombSargaMenu', this.visszaAFomenube, this)
        }
    },pauseVege: function() {
        this.lehetValasztani = 1;
        this.megallitva = 0;
        this.fedoreteg.kill();
        this.pausedHatter.kill();
        this.gombSargaPlay.kill();
        this.gombSargaRestart.kill();
        this.gombSargaMenu.kill();
        this.mozgatas()
    },elolrolKezdes: function() {
        this.game.state.start('Game')
    },visszaAFomenube: function() {
        this.game.state.start('MainMenu')
    },comboSzovegKiiras: function() {
        if (this.combok > 1) {
            var pluszPont = 100;
            var pluszSzoveg = "";
            if (this.combok > 2) {
                pluszSzoveg = "\nGOOD";
                pluszPont = 200
            }
            if (this.combok > 4) {
                pluszSzoveg = "\nGREAT";
                pluszPont = 400
            }
            if (this.combok > 6) {
                pluszSzoveg = "\nAWESOME";
                pluszPont = 800
            }
            this.score_frissit(pluszPont);
            this.comboSzoveg.setText("COMBO " + this.combok + "x\n+" + pluszPont + pluszSzoveg);
            this.comboSzoveg.visible = 1;
            clearTimeout(this.comboEltunikAnim);
            this.comboSzoveg.alpha = 0;
            this.comboSzoveg.y = 250;
            var comboAnim = this.add.tween(this.comboSzoveg).to({y: 300,alpha: 1}, 600, Phaser.Easing.Circular.Out, true, 0, 0, false);
            var that = this;
            this.comboEltunikAnim = setTimeout(function() {
                that.add.tween(that.comboSzoveg).to({y: 250,alpha: 0}, 600, Phaser.Easing.Circular.Out, true, 1000, 0, false)
            }, 1000);
            this.comboNagyAnim.revive();
            this.comboNagyAnim.animations.add('run');
            this.comboNagyAnim.width = 500;
            this.comboNagyAnim.height = 500;
            this.comboNagyAnim.animations.play('run', 35, false, true);
            return;
            var eloKellHozni = 0;
            if (this.comboSzoveg.alpha != 1) {
                eloKellHozni = 1
            }
            if (eloKellHozni == 1) {
                if (this.comboEltunikAnim != "") {
                    this.comboEltunikAnim.destroy();
                    this.comboEltunikAnim = ""
                }
                var comboAnim = this.add.tween(this.comboSzoveg).to({y: 300,alpha: 1}, 600, Phaser.Easing.Circular.Out, true, 0, 0, false);
                this.comboEltunikAnim = this.add.tween(this.comboSzoveg).to({y: 250,alpha: 0}, 2600, Phaser.Easing.Circular.Out, true, 1000, 0, false)
            } else {
            }
            return;
            if (this.comboEltunikAnim != "") {
                this.comboEltunikAnim.stop()
            }
            var comboAnim = this.add.tween(this.comboSzoveg).to({y: 300,alpha: 1}, 600, Phaser.Easing.Circular.Out, true, 0, 0, false);
            var that = this;
            comboAnim.onComplete.add(function() {
                that.comboEltunikAnim = that.add.tween(that.comboSzoveg).to({y: 250,alpha: 0}, 600, Phaser.Easing.Circular.Out, true, 1000, 0, false)
            })
        }
    },skillHaszanalatEgyikElemEltuntetese: function() {
        var mennyiVanMeg = TeddyGame.alapAdatok.skill2HanyszorHasznalhato - this.skill2HanyszorHasznalva;
        if (this.lehetValasztani && mennyiVanMeg > 0) {
            this.time.events.remove(this.miotaNemTudottLepniTimer);
            this.sugoGrafika.kill();
            this.sugoGrafika2.kill();
            this.egyebAnim1.revive();
            this.egyebAnim1.animations.add('run');
            this.egyebAnim1.width = 500;
            this.egyebAnim1.height = 500;
            this.egyebAnim1.animations.play('run', 25, false, true);
            this.hangEltunes2.play();
            this.skill2HanyszorHasznalva += 1;
            var ujszoveg = TeddyGame.alapAdatok.skill2HanyszorHasznalhato - this.skill2HanyszorHasznalva;
            this.skill2DarabSzoveg.setText("" + ujszoveg);
            this.add.tween(this.skillGomb2).to({width: 70,height: 70}, 100, Phaser.Easing.Linear.None).to({width: 75,height: 75}, 100, Phaser.Easing.Linear.None).start();
            this.kivalasztott_elem_1 = "";
            this.kivalasztott_elem_2 = "";
            this.lehetValasztani = 0;
            var key = this.elemek[0][0].melyik_sprite;
            for (var x = 0; x < this.vizszintesDarab; x++) {
                for (var y = 0; y < this.fuggolegesDarab; y++) {
                    if (this.elemek[x][y].melyik_sprite == key) {
                        this.elemek[x][y].pusztitaniKell = 1
                    }
                }
            }
            this.pusztitKonkret()
        } else {
            this.nemLehetASkilltHasznalni()
        }
    },skillHaszanalatRobbantasKozepen: function() {
        var mennyiVanMeg = TeddyGame.alapAdatok.skill1HanyszorHasznalhato - this.skill1HanyszorHasznalva;
        if (this.lehetValasztani && mennyiVanMeg > 0) {
            this.time.events.remove(this.miotaNemTudottLepniTimer);
            this.sugoGrafika.kill();
            this.sugoGrafika2.kill();
            this.egyebAnim2.revive();
            this.egyebAnim2.animations.add('run');
            this.egyebAnim2.width = 500;
            this.egyebAnim2.height = 500;
            this.egyebAnim2.animations.play('run', 35, false, true);
            this.sound.play('hangRobbanas');
            this.skill1HanyszorHasznalva += 1;
            var ujszoveg = TeddyGame.alapAdatok.skill1HanyszorHasznalhato - this.skill1HanyszorHasznalva;
            this.skill1DarabSzoveg.setText("" + ujszoveg);
            this.add.tween(this.skillGomb1).to({width: 70,height: 70}, 100, Phaser.Easing.Linear.None).to({width: 75,height: 75}, 100, Phaser.Easing.Linear.None).start();
            this.kivalasztott_elem_1 = "";
            this.kivalasztott_elem_2 = "";
            this.lehetValasztani = 0;
            this.elemek[2][3].pusztitaniKell = 1;
            this.elemek[3][3].pusztitaniKell = 1;
            this.elemek[4][3].pusztitaniKell = 1;
            this.elemek[2][4].pusztitaniKell = 1;
            this.elemek[3][4].pusztitaniKell = 1;
            this.elemek[4][4].pusztitaniKell = 1;
            this.pusztitKonkret()
        } else {
            this.nemLehetASkilltHasznalni()
        }
    },nemLehetASkilltHasznalni: function() {
        this.sound.play('negativ')
    },szintNemSikerultEsemeny: function() {
        TeddyGame.alapAdatok.mennyiPontotGyujtottEppen = this.score;
        TeddyGame.alapAdatok.mennyiCombotGyujtottEppen = this.combokOsszesen;
        this.game.state.start('SzintNemSikerult')
    },update: function() {
        if (this.szintNemSikerult == false && this.szintMegnyerve == false && this.megallitva == 0) {
            if (this.time.now > this.idoTime) {
                this.idoTime = this.time.now + 100;
                var mennyitKellCsokkenteni = (450 / this.mennyiIdejeVan) / 10;
                if (this.ido_progressbar.width - mennyitKellCsokkenteni > 0) {
                    this.ido_progressbar.width -= mennyitKellCsokkenteni
                } else {
                    this.ido_progressbar.width = 0;
                    this.szintNemSikerult = true;
                    this.szintNemSikerultEsemeny()
                }
            }
        }
    },quitGame: function(pointer) {
        this.game.state.start('MainMenu')
    },score_frissit: function(mennyivel) {
        this.score += mennyivel;
        this.scoreSzoveg.setText("" + this.score)
    },getRandomInt: function(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min
    },particleBurst: function(hol) {
        var kispont = this.add.bitmapText(hol.x - 15, hol.y - 5, 'carter', '+25', 16);
        this.elemekGroup.add(kispont);
        var kispontAnim = this.add.tween(kispont).to({y: hol.y - 30,alpha: 0}, 1500, Phaser.Easing.Quadratic.Out, true, 500, 0, false);
        kispontAnim.onComplete.add(function() {
            this.destroy()
        }, kispont);
        if (hol.melyik_sprite == "1" || hol.melyik_sprite == "5") {
            var explosion = this.explosions.getFirstDead()
        }
        if (hol.melyik_sprite == "2." || hol.melyik_sprite == "6") {
            var explosion = this.explosions2.getFirstDead()
        }
        if (hol.melyik_sprite == "3" || hol.melyik_sprite == "7") {
            var explosion = this.explosions3.getFirstDead()
        }
        if (hol.melyik_sprite == "4" || hol.melyik_sprite == "8") {
            var explosion = this.explosions4.getFirstDead()
        }
        if (explosion) {
            explosion.reset(hol.x - 60, hol.y - 60);
            explosion.width = this.elemSzelesseg * 1.5;
            explosion.height = this.elemMagassag * 1.5;
            explosion.animations.add('kaboom');
            explosion.play('kaboom', 30, false, true)
        }
        return;
        this.emitter.x = hol.x + 15;
        this.emitter.y = hol.y;
        console.log("emitter:");
        this.emitter.start(true, 1000, null, 120);
        console.log(this.emitter);
        setTimeout(function() {
        }, 2000)
    },ujElem: function(x, y, palyaLetrehozas) {
        this.hanyadikElem++;
        var melyik = this.getRandomInt(1, TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].hanyfeleElemVan);
        var melyik_sprite_neve = "";
        var asd = {};
        asd[0] = [1, 2, 3, 1, 2, 3, 1, 2, 3];
        asd[1] = [2, 1, 1, 1, 2, 3, 1, 2, 3];
        asd[2] = [2, 1, 1, 1, 2, 3, 1, 2, 3];
        asd[3] = [2, 2, 3, 1, 2, 3, 1, 2, 3];
        asd[4] = [2, 2, 3, 1, 2, 3, 1, 2, 3];
        asd[5] = [3, 2, 3, 1, 2, 3, 1, 2, 3];
        asd[6] = [1, 2, 3, 1, 2, 3, 1, 2, 3];
        asd[7] = [1, 2, 3, 1, 2, 3, 1, 2, 3];
        if (melyik == 1) {
            melyik_sprite_neve = "1.png";
            melyik_sprite = 1
        }
        if (melyik == 2) {
            melyik_sprite_neve = "2.png";
            melyik_sprite = 2
        }
        if (melyik == 3) {
            melyik_sprite_neve = "3.png";
            melyik_sprite = 3
        }
        if (melyik == 4) {
            melyik_sprite_neve = "4.png";
            melyik_sprite = 4
        }
        if (melyik == 5) {
            melyik_sprite_neve = "5.png";
            melyik_sprite = 5
        }
        if (melyik == 6) {
            melyik_sprite_neve = "6.png";
            melyik_sprite = 6
        }
        if (melyik == 7) {
            melyik_sprite_neve = "7.png";
            melyik_sprite = 7
        }
        if (melyik == 8) {
            melyik_sprite_neve = "8.png";
            melyik_sprite = 8
        }
        if (palyaLetrehozas == 1) {
            if (x > 1) {
                if (this.elemek[x - 2][y].melyik_sprite_neve == melyik_sprite_neve && this.elemek[x - 1][y].melyik_sprite_neve == melyik_sprite_neve) {
                    melyik_sprite_neve = this.getNemEgyezoUjElem(melyik_sprite_neve)
                }
            }
            if (y > 1) {
                if (this.elemek[x][y - 2].melyik_sprite_neve == melyik_sprite_neve && this.elemek[x][y - 1].melyik_sprite_neve == melyik_sprite_neve) {
                    melyik_sprite_neve = this.getNemEgyezoUjElem(melyik_sprite_neve)
                }
            }
        }
        var specialisJon = 0;
        var specialisTipus = "";
        var specialisJonRnd = this.getRandomInt(1, 100);
        if (specialisJonRnd < 5) {
            var specialisJonRndMelyik = this.getRandomInt(1, 3);
            if (specialisJonRndMelyik == 1) {
                var mennyitGyujthet = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujthet;
                var mennyitGyujtott = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujtott;
                if (this.csillagMennyiVanKint < (mennyitGyujthet - mennyitGyujtott)) {
                    specialisJon = 1;
                    this.csillagMennyiVanKint++;
                    specialisTipus = "specialisElemCsillag";
                    melyik_sprite_neve = "csillagElem.png";
                    melyik_sprite = 9
                }
            }
            if (specialisJonRndMelyik == 2) {
                var mennyitGyujthet = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujthet;
                var mennyitGyujtott = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujtott;
                if (this.artifaktMennyiVanKint < (mennyitGyujthet - mennyitGyujtott)) {
                    specialisJon = 1;
                    this.artifaktMennyiVanKint++;
                    specialisTipus = "specialisElemArtifakt";
                    melyik_sprite_neve = "vilag1arifact1.png";
                    melyik_sprite = 10
                }
            }
            if (specialisJonRndMelyik == 3) {
                if (TeddyGame.alapAdatok.melyikVilagbanJatszikEppen == 1) {
                    specialisJon = 1;
                    specialisTipus = "lancolt";
                    melyik_sprite_neve = "1z.png";
                    melyik_sprite = 1
                }
            }
        }
        var hovaValoY = 25 + (y * this.elemMagassag);
        var item = this.elemekGroup.create(25 + (x * this.elemSzelesseg), -75, 'vilag' + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen + 'Elemek', melyik_sprite_neve);
        item.width = (this.elemSzelesseg - 20);
        item.height = (this.elemMagassag - 20);
        item.alpha = 0;
        item.inputEnabled = true;
        item.anchor.setTo(0.5, 0.5);
        item.body = null;
        item.events.onInputDown.add(this.elemreKattint, this);
        item.events.onInputUp.add(this.elemenElenged, this);
        item.melyik_sprite_neve = melyik_sprite_neve;
        item.pusztitaniKell = 0;
        item.elemekX = x;
        item.elemekY = y;
        item.specialisTipus = specialisTipus;
        item.melyik_sprite = melyik_sprite;
        this.elemek[x][y] = item;
        if (palyaLetrehozas == 1) {
            item.alpha = 1;
            item.y = hovaValoY;
            item.width = 0;
            item.height = 0;
            this.add.tween(item).to({width: (this.elemSzelesseg - 20),height: (this.elemMagassag - 20)}, 500, Phaser.Easing.Quadratic.InOut, true, (this.hanyadikElem * 10), 0, false)
        } else {
            this.add.tween(item).to({y: hovaValoY,alpha: 1}, 600, Phaser.Easing.Bounce.Out, true, 0, 0, false)
        }
    },getNemEgyezoUjElem: function(melyik) {
        var osszesElem = new Array();
        for (var i = 1; i <= TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].hanyfeleElemVan; i++) {
            osszesElem.push(i + ".png")
        }
        osszesElem.splice(osszesElem.indexOf(melyik), 1);
        var r = this.getRandomInt(0, osszesElem.length - 1);
        return osszesElem[r]
    },elem1kivalasztasa: function(elem) {
        if (this.kivalasztottElemAnim != "") {
            this.kivalasztottElemAnim.stop();
            if (this.kivalasztott_elem_1 != "") {
                this.kivalasztott_elem_1.angle = -360
            }
        }
        this.kivalasztott_elem_1 = elem;
        this.kivalasztottElemAnim = this.add.tween(elem).to({angle: 360}, 500, Phaser.Easing.Linear.In, true, 0, 50, false)
    },elemenElenged: function(elem) {
        if (this.lehetValasztani == 1) {
            if (this.kivalasztott_elem_1 != "") {
                var mit = "";
                if (this.input.y < elem.world.y - 50) {
                    mit = this.elemek[elem.elemekX][elem.elemekY - 1]
                }
                if (this.input.y > elem.world.y + 50) {
                    mit = this.elemek[elem.elemekX][elem.elemekY + 1]
                }
                if (this.input.x > elem.world.x + 50) {
                    mit = this.elemek[elem.elemekX + 1][elem.elemekY]
                }
                if (this.input.x < elem.world.x - 50) {
                    mit = this.elemek[elem.elemekX - 1][elem.elemekY]
                }
                if (mit != "") {
                    this.elem2kivalasztasa(mit)
                }
            }
        }
    },elem2kivalasztasa: function(elem) {
        if (elem.specialisTipus == "lancolt") {
            this.sound.play('negativ');
            return
        }
        if (this.kivalasztott_elem_1 != elem) {
            this.sound.play('hangMenuClick');
            if (this.kivalasztott_elem_1.elemekX > elem.elemekX) {
                if (this.kivalasztott_elem_1.elemekX - elem.elemekX != 1) {
                    this.elem1kivalasztasa(elem);
                    return
                }
                if (this.kivalasztott_elem_1.elemekY != elem.elemekY) {
                    this.elem1kivalasztasa(elem);
                    return
                }
            }
            if (this.kivalasztott_elem_1.elemekX < elem.elemekX) {
                if (elem.elemekX - this.kivalasztott_elem_1.elemekX != 1) {
                    this.elem1kivalasztasa(elem);
                    return
                }
                if (this.kivalasztott_elem_1.elemekY != elem.elemekY) {
                    this.elem1kivalasztasa(elem);
                    return
                }
            }
            if (this.kivalasztott_elem_1.elemekY > elem.elemekY) {
                if (this.kivalasztott_elem_1.elemekY - elem.elemekY != 1) {
                    this.elem1kivalasztasa(elem);
                    return
                }
                if (this.kivalasztott_elem_1.elemekX != elem.elemekX) {
                    this.elem1kivalasztasa(elem);
                    return
                }
            }
            if (this.kivalasztott_elem_1.elemekY < elem.elemekY) {
                if (elem.elemekY - this.kivalasztott_elem_1.elemekY != 1) {
                    this.elem1kivalasztasa(elem);
                    return
                }
                if (this.kivalasztott_elem_1.elemekX != elem.elemekX) {
                    this.elem1kivalasztasa(elem);
                    return
                }
            }
            this.kivalasztottElemAnim.stop();
            this.kivalasztott_elem_1.angle = 0;
            this.lehetValasztani = 0;
            this.kivalasztott_elem_2 = elem;
            var temp_kivalasztott_elem_1 = this.kivalasztott_elem_1;
            var temp_kivalasztott_elem_2 = this.kivalasztott_elem_2;
            var e1x = this.kivalasztott_elem_1.x;
            var e1y = this.kivalasztott_elem_1.y;
            var e2x = this.kivalasztott_elem_2.x;
            var e2y = this.kivalasztott_elem_2.y;
            var et1x = this.kivalasztott_elem_1.elemekX;
            var et1y = this.kivalasztott_elem_1.elemekY;
            var et2x = this.kivalasztott_elem_2.elemekX;
            var et2y = this.kivalasztott_elem_2.elemekY;
            this.elemek[et1x][et1y].elemekX = et2x;
            this.elemek[et1x][et1y].elemekY = et2y;
            this.elemek[et2x][et2y].elemekX = et1x;
            this.elemek[et2x][et2y].elemekY = et1y;
            this.elemek[et1x][et1y] = this.kivalasztott_elem_2;
            this.elemek[et2x][et2y] = this.kivalasztott_elem_1;
            this.kivalasztott_elem_1_tween = this.add.tween(this.kivalasztott_elem_1).to({x: e2x,y: e2y}, 300, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
            this.kivalasztott_elem_2_tween = this.add.tween(this.kivalasztott_elem_2).to({x: e1x,y: e1y}, 300, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
            var that = this;
            this.kivalasztott_elem_1_tween.onComplete.add(this.t1completed, this)
        } else {
        }
    },elemreKattint: function(elem) {
        if (this.lehetValasztani == 1) {
            if (this.kivalasztott_elem_1 == "") {
                if (elem.specialisTipus != "lancolt") {
                    this.hangMenuClick.play();
                    this.elem1kivalasztasa(elem)
                } else {
                    this.sound.play('negativ')
                }
            } else {
                this.elem2kivalasztasa(elem)
            }
        }
    },t1completed: function() {
        this.pusztitasraJelolV2();
        if (this.hanyatKellTorolni >= 3) {
            this.pusztitKonkret();
            this.time.events.remove(this.miotaNemTudottLepniTimer);
            this.miotaNemTudottLepniTimer = this.time.events.add(this.sugoMennyiIdoMulva, this.nemTudottLepni, this);
            this.sugoGrafika.kill();
            this.sugoGrafika2.kill()
        } else {
            this.visszallit()
        }
        this.kivalasztott_elem_1 = "";
        this.kivalasztott_elem_2 = ""
    },szivProgressFrissit: function() {
        var szazalek = this.mennyitTuntetettEl / this.mennyitKellEltuntetnie;
        if (szazalek >= 1) {
            this.sziv_progressbar.width = 450;
            this.szintMegnyerve = true;
            this.lehetValasztani = 0;
            if (this.szintMegnyerveTovabb == 0) {
                var fedo = this.add.sprite(0, 0, 'fedoreteg');
                fedo.width = 600;
                fedo.height = 1000;
                fedo.alpha = 0.8;
                var completedSzoveg = this.add.bitmapText(-200, 220, 'carter', "Level completed!", 35);
                this.add.tween(completedSzoveg).to({x: 30}, 500, Phaser.Easing.Quadratic.Out, true, 0, 0, false);
                var fomenuGombContinue = this.add.button(200, 330, 'fomenuGombContinue', this.szintMegnyerveTovabbGombKlikk, this, 0, 0, 1)
            }
        } else {
            this.sziv_progressbar.width = (450 * szazalek)
        }
    },szintMegnyerveTovabbGombKlikk: function() {
        if (TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].megnyertSzintek < TeddyGame.alapAdatok.melyikSzintenJatszikEppen) {
            TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen].megnyertSzintek = TeddyGame.alapAdatok.melyikSzintenJatszikEppen
        }
        TeddyGame.alapAdatok.mennyiPontotGyujtottEppen = this.score;
        TeddyGame.alapAdatok.mennyiCombotGyujtottEppen = this.combokOsszesen;
        var legtobbElertPont = TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].letobbElertPont;
        if (legtobbElertPont < TeddyGame.alapAdatok.mennyiPontotGyujtottEppen) {
            TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].letobbElertPont = TeddyGame.alapAdatok.mennyiPontotGyujtottEppen
        }
        TeddyGame.Boot.prototype.adatokMentese();
        this.game.state.start('SzintMegnyerve')
    },csillagfrissit: function(mennyivel) {
        this.csillag += mennyivel;
        this.csillagSzoveg.setText(this.csillag + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujthet);
        TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiCsillagotGyujtott += mennyivel;
        TeddyGame.alapAdatok.mennyiCsillagotGyujtottOsszesen += mennyivel;
        TeddyGame.Boot.prototype.adatokMentese()
    },artifaktfrissit: function(mennyivel) {
        this.artifakt += mennyivel;
        this.artifaktSzoveg.setText(this.artifakt + "/" + TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujthet);
        TeddyGame.alapAdatok.vilagokEsSzintek["vilag" + TeddyGame.alapAdatok.melyikVilagbanJatszikEppen]["szint" + TeddyGame.alapAdatok.melyikSzintenJatszikEppen].mennyiArtifaktotGyujtott += mennyivel;
        TeddyGame.Boot.prototype.adatokMentese()
    },pusztitKonkret: function() {
        var kellFrissites = 0;
        var elpusztitvaEbbenAVizsgalatban = 0;
        for (var y = 0; y < this.fuggolegesDarab; y++) {
            for (var x = 0; x < this.vizszintesDarab; x++) {
                if (this.elemek[x][y].specialisTipus == "specialisElemCsillag" && this.elemek[x][y].elemekY == this.fuggolegesDarab - 1) {
                    this.elemek[x][y].pusztitaniKell = 1;
                    var tweeneloCsillag = this.add.sprite(this.elemek[x][y].world.x, this.elemek[x][y].world.y, 'specialisElemCsillag');
                    tweeneloCsillag.width = this.elemSzelesseg;
                    tweeneloCsillag.height = this.elemMagassag;
                    var csillagTween = this.add.tween(tweeneloCsillag).to({x: 320,y: 10,width: 50,height: 50,angle: 360}, 2100, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
                    this.sound.play('csillag');
                    var that = this;
                    csillagTween.onComplete.add(function() {
                        that.csillagfrissit(1);
                        this.destroy()
                    }, tweeneloCsillag)
                }
                if (this.elemek[x][y].specialisTipus == "specialisElemArtifakt" && this.elemek[x][y].elemekY == this.fuggolegesDarab - 1) {
                    this.elemek[x][y].pusztitaniKell = 1;
                    var tweeneloArtifakt = this.add.sprite(this.elemek[x][y].world.x, this.elemek[x][y].world.y, 'specialisElemArtifakt11');
                    tweeneloArtifakt.width = this.elemSzelesseg;
                    tweeneloArtifakt.height = this.elemMagassag;
                    var artifaktTween = this.add.tween(tweeneloArtifakt).to({x: 420,y: 10,width: 50,height: 50,angle: 360}, 2100, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
                    this.sound.play('csillag');
                    var that = this;
                    artifaktTween.onComplete.add(function() {
                        that.artifaktfrissit(1);
                        this.destroy()
                    }, tweeneloArtifakt)
                }
                if (this.elemek[x][y].pusztitaniKell == 1) {
                    elpusztitvaEbbenAVizsgalatban++;
                    this.mennyitTuntetettEl++;
                    kellFrissites = 1;
                    this.particleBurst(this.elemek[x][y]);
                    var t4 = this.add.tween(this.elemek[x][y]).to({width: 0,height: 0}, 300, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
                    var that = this;
                    var asd = "ez az asd";
                    t4.onComplete.add(function() {
                        this.destroy()
                    }, this.elemek[x][y]);
                    this.score_frissit(25)
                }
            }
        }
        var that = this;
        if (kellFrissites) {
            this.hangEltunes1.play();
            this.combok++;
            this.combokOsszesen++;
            this.comboSzovegKiiras();
            this.szivProgressFrissit();
            setTimeout(function() {
                that.mozgatas()
            }, 350)
        } else {
            this.combok = 0;
            this.lehetValasztani = 1
        }
    },visszallit: function() {
        var temp_kivalasztott_elem_1 = this.kivalasztott_elem_1;
        var temp_kivalasztott_elem_2 = this.kivalasztott_elem_2;
        var e1x = this.kivalasztott_elem_1.x;
        var e1y = this.kivalasztott_elem_1.y;
        var e2x = this.kivalasztott_elem_2.x;
        var e2y = this.kivalasztott_elem_2.y;
        var et1x = this.kivalasztott_elem_1.elemekX;
        var et1y = this.kivalasztott_elem_1.elemekY;
        var et2x = this.kivalasztott_elem_2.elemekX;
        var et2y = this.kivalasztott_elem_2.elemekY;
        this.elemek[et1x][et1y].elemekX = et2x;
        this.elemek[et1x][et1y].elemekY = et2y;
        this.elemek[et2x][et2y].elemekX = et1x;
        this.elemek[et2x][et2y].elemekY = et1y;
        this.elemek[et1x][et1y] = this.kivalasztott_elem_2;
        this.elemek[et2x][et2y] = this.kivalasztott_elem_1;
        var t1 = this.add.tween(this.kivalasztott_elem_1).to({x: e2x,y: e2y}, 300, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
        var t2 = this.add.tween(this.kivalasztott_elem_2).to({x: e1x,y: e1y}, 300, Phaser.Easing.Quadratic.InOut, true, 0, 0, false);
        var that = this;
        t1.onComplete.add(function() {
            that.lehetValasztani = 1
        })
    },mozgatas: function() {
        if (this.megallitva == 1) {
            return
        }
        for (var x = 0; x < this.vizszintesDarab; x++) {
            if (this.elemek[x][0].pusztitaniKell == 1) {
                this.ujElem(x, 0, 0)
            }
        }
        for (var y = 1; y < this.fuggolegesDarab; y++) {
            for (var x = 0; x < this.vizszintesDarab; x++) {
                if (this.elemek[x][y].pusztitaniKell == 1) {
                    for (var k = y; k >= 1; k--) {
                        if (this.elemek[x][k - 1].pusztitaniKell == 1) {
                            break
                        }
                        this.elemek[x][k] = this.elemek[x][k - 1];
                        this.elemek[x][k].elemekY = (this.elemek[x][k].elemekY) + 1;
                        this.elemek[x][k].pusztitaniKell = 0;
                        var t4 = this.add.tween(this.elemek[x][k]).to({y: 25 + (this.elemek[x][k].elemekY * this.elemMagassag)}, 600, Phaser.Easing.Bounce.Out, true, 0, 0, false);
                        var that = this
                    }
                    this.ujElem(x, 0, 0)
                }
            }
        }
        this.sound.play('hangEsik1');
        var that = this;
        if (this.szintMegnyerve == 0) {
            setTimeout(function() {
                that.pusztitasraJelolV2();
                that.pusztitKonkret()
            }, 500)
        }
    },pusztitasraJelolV2: function() {
        this.lehetvalasztani = 0;
        var key;
        var talalat = 0;
        var vanTalalat = 0;
        var elsoTalalat = 0;
        for (var y = 0; y < this.fuggolegesDarab; y++) {
            key = this.elemek[0][y].melyik_sprite;
            talalat = 1;
            for (var x = 1; x < this.vizszintesDarab; x++) {
                if (this.elemek[x][y].melyik_sprite == key && (this.elemek[x][y].specialisTipus != "specialisElemCsillag" && this.elemek[x][y].specialisTipus != "specialisElemArtifakt")) {
                    talalat++
                } else {
                    if (talalat >= 3) {
                        for (var k = 0; k < talalat; k++) {
                            this.elemek[x - k - 1][y].pusztitaniKell = 1
                        }
                    }
                    key = this.elemek[x][y].melyik_sprite;
                    talalat = 1
                }
            }
            if (talalat >= 3) {
                for (var k = 0; k < talalat; k++) {
                    this.elemek[x - k - 1][y].pusztitaniKell = 1
                }
            }
        }
        for (var x = 0; x < this.vizszintesDarab; x++) {
            key = this.elemek[x][0].melyik_sprite;
            talalat = 1;
            for (var y = 1; y < this.fuggolegesDarab; y++) {
                if (this.elemek[x][y].melyik_sprite == key && (this.elemek[x][y].specialisTipus != "specialisElemCsillag" && this.elemek[x][y].specialisTipus != "specialisElemArtifakt")) {
                    talalat++
                } else {
                    if (talalat >= 3) {
                        for (var k = 0; k < talalat; k++) {
                            this.elemek[x][y - k - 1].pusztitaniKell = 1
                        }
                    }
                    key = this.elemek[x][y].melyik_sprite;
                    talalat = 1
                }
            }
            if (talalat >= 3) {
                for (var k = 0; k < talalat; k++) {
                    this.elemek[x][y - k - 1].pusztitaniKell = 1
                }
            }
        }
        this.hanyatKellTorolni = 0;
        for (var x = 0; x < this.vizszintesDarab; x++) {
            for (var y = 0; y < this.fuggolegesDarab; y++) {
                if (this.elemek[x][y].pusztitaniKell == 1) {
                    this.hanyatKellTorolni++
                }
            }
        }
    },debugelemek: function() {
        for (var y = 0; y < 6; y++) {
            var mitsor = y + " ";
            for (var x = 0; x < 6; x++) {
                var mit = "";
                if (this.elemek[x][y].melyik_sprite_neve == "apple") {
                    mit += "A"
                }
                if (this.elemek[x][y].melyik_sprite_neve == "bag") {
                    mit += "B"
                }
                if (this.elemek[x][y].melyik_sprite_neve == "logo") {
                    mit += "C"
                }
                if (this.elemek[x][y].pusztitaniKell == 1) {
                    mit += "o"
                } else {
                    mit += "x"
                }
                mitsor += mit
            }
            console.log(mitsor)
        }
    },render: function() {
    }};
