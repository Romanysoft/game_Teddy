/**
 * Created by Ian on 2014/8/10.
 */

(function(){
    var b$ = {};

    b$.pNative = (typeof maccocojs !== 'undefined') && (maccocojs); // 本地引擎
    b$.cb_execTaskUpdateInfo = null; //执行任务的回调
    b$.pCorePlugin = { //核心处理引导插件部分,尽量不要修改
        useThread: true,
        passBack:"BS.b$.cb_execTaskUpdateInfo",
        packageMode: 'bundle',
        taskToolPath: "/Plugins/extendLoader.bundle",
        bundleClassName: "LibCommonInterface"
    };

    b$.pIAPPlugin = {
        path:"/plugin.iap.bundle"
    };

    // IAP 功能封装
    b$.cb_handleIAPCallback = null; // IAP的回调函数
    b$.IAP = {
        enableIAP : function(parms){
            if(b$.pNative){
                try{
                    //注册IAP回调
                    b$.pNative.iap.regeditIAPCallbackJs(parms.cb_IAP_js || "BS.b$.cb_handleIAPCallback");

                    //注册IAPBundle
                    b$.pNative.iap.regeditIAPCore($.toJSON({
                        path:b$.getAppPluginDir() + b$.pIAPPlugin.path
                    }));

                    //看看是否可以起诉购买
                    if(b$.pNative.iap.canMakePayments()){
                        //启动服务
                        b$.pNative.iap.startIAPService();

                        //发送商品请求
                        b$.pNative.iap.requestProducts($.toJSON({
                            productIdentifiers:parms.productIds ||[]
                        }));
                    }
                }catch(e){
                    console.error(e);
                }

            }
        },

        restore:function(){
            if(b$.pNative){
                //发送购买请求
                b$.pNative.iap.restoreIAP();
            }
        },

        buyProduct:function(parms){
            if(b$.pNative){
                //发送购买请求
                b$.pNative.iap.buyProduct($.toJSON({
                    identifier:parms.productIdentifier,
                    quantity:parms.quantity || 1
                }));
            }
        },

        getPrice:function(productIdentifier){
            if(b$.pNative){
                return b$.pNative.iap.getPrice(productIdentifier);
            }

            return "";
        },

        getUseableProductCount: function(productIdentifier){
            if(b$.pNative){
                return b$.pNative.iap.getUseableProductCount(productIdentifier);
            }

            return 0;
        },
		
		setUseableProductCount:function(jsonObj){
            if(b$.pNative){
				var params = {
					identifier: jsonObj.productIdentifier || '',
					quantity: jsonObj.quantity || 1
				};
                return b$.pNative.iap.setUseableProductCount($.toJSON(params));
            }

            return 0;
		},

        add1Useable : function(productIdentifier){
            if(b$.pNative){
                return b$.pNative.iap.add1Useable(productIdentifier);
            }

            return 0;
        },

        sub1Useable : function(productIdentifier){
            if(b$.pNative){
                return b$.pNative.iap.sub1Useable(productIdentifier);
            }

            return 0;
        }
    };
	
    /**
     * Notice 内容封装
     */
	b$.Notice = {
		alert:function(jsonObj){
            if(b$.pNative){
				var params = {
					message: jsonObj.message || 'Tip',
					title: jsonObj.title || 'title',
					buttons: jsonObj.buttons || ['Ok'],
					alertType: jsonObj.alertType || 'Alert'
				};
			
                return b$.pNative.notice.alert($.toJSON(params));
            }
		}
	};

    /**
     * App 内容封装
     */
    b$.App = {
        getAppName:function(){
            if(b$.pNative){
                return b$.pNative.app.getAppName();
            }
            return "AppName";
        },

        getAppVersion:function(){
            if(b$.pNative){
                return b$.pNative.app.getAppVersion();
            }
            return "4.5.6";
        },

        open:function(data){
            if(b$.pNative){
                return b$.pNative.app.open(data);
            }
        }
    };


    // 启动核心插件功能
    b$.enablePluginCore = function(pluginList){
        if(b$.pNative){
            try{
                var pluginArray = pluginList || []; // 插件信息数组
                var extendObj = $.objClone(b$.pCorePlugin);
                extendObj["callMethod"] = "initCore";
                extendObj["arguments"] = [
                    true,
                    pluginArray
                ];

                b$.pNative.window.execTask($.toJSON(extendObj));

            }catch (e){
                console.error(e);
            }
        }
    };

    // 启用拖拽功能
    b$.cb_dragdrop = null; // 启动
    b$.enableDragDropFeature = function(obj){
        if(b$.pNative){
            try{
                b$.pNative.window.setDragDropCallback($.toJSON({callback: "BS.b$.cb_dragdrop"}));
                b$.pNative.window.setDragDropAllowDirectory($.toJSON({enableDir: obj.enableDir ||false}));
                b$.pNative.window.setDragDropAllowFileTypes($.toJSON({fileTypes: obj.fileTypes || ["*"]}));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 创建任务
    /**
     *
     * @param callMethod  调用方式：task，sendEvent，
     * @param taskId
     * @param args
     */
    b$.createTask = function(callMethod, taskId, args){
        if(b$.pNative){
            try{
                var extendObj = $.objClone(b$.pCorePlugin);
                extendObj["callMethod"] = callMethod;
                extendObj["arguments"] = [taskId, args];

                b$.pNative.window.execTask($.toJSON(extendObj));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 发送任务事件
    b$.sendQueueEvent = function(queueID, queueType, event){
        if(b$.pNative){
            try{
                var extendObj = $.objClone(b$.pCorePlugin);
                extendObj["callMethod"] = "sendEvent";
                extendObj["arguments"] = [event, queueType, queueID];

                b$.pNative.window.execTask($.toJSON(extendObj));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 导入文件
    b$.cb_importFiles = null; // 导入文件的回调
    b$.importFiles = function(parms){
        if(b$.pNative){
            try{
                b$.pNative.window.openFile($.toJSON(parms));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 选择输出目录
    b$.cb_selectOutDir = null; // 选择输出目录的回调
    b$.selectOutDir = function(parms){
        if(b$.pNative){
            try{
                b$.pNative.window.openFile($.toJSON(parms));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 选择输出文件
    b$.cb_selectOutFile = null; // 选择输出文件的回调
    b$.selectOutFile = function(parms){
        if(b$.pNative){
            try{
                b$.pNative.window.saveFile($.toJSON(parms));
            }catch(e){
                console.error(e);
            }
        }
    };

    // 定位文件
    b$.cb_revealInFinder = null; // 选择定位文件的回调
    b$.revealInFinder = function(path){
        if(b$.pNative){
            try{
                b$.pNative.window.revealInFinder($.toJSON({
                    filePath:path
                }));
            }catch(e){
                console.error(e)
            }
        }
    };

    // 获得App的插件目录
    b$.getAppPluginDir = function(){
        if(b$.pNative){
            return b$.pNative.path.appPluginDirPath();
        }
        return "";
    };

    // 获得Public目录
    b$.getAppResourcePublicDir = function(){
        if(b$.pNative){
            return b$.pNative.path.resource() + "/public";
        }
        return "";
    };



    // 检测路径是否存在
    b$.pathIsExist = function(path){
        if(b$.pNative){
            return b$.pNative.path.pathIsExist(path);
        }
        return true;
    };

    // 检测路径是否可写
    b$.checkPathIsWritable = function(path){
        if(b$.pNative){
            return b$.pNative.path.checkPathIsWritable(path);
        }
        return true;
    };

    // 检测文件是否为0Byte字节
    b$.checkFileIsZeroSize = function(path){
        if(b$.pNative){
            return b$.pNative.path.fileIsZeroSize(path);
        }
        return false;
    };

    // 删除文件
    b$.removeFile = function(path){
        if(b$.pNative){
            return b$.pNative.window.removeFile($.toJSON({path:path}));
        }
    };

    // 查找文件
    b$.findFile = function(dir, fileName){
        if(b$.pNative){
            return b$.pNative.window.findFile($.toJSON({dir:dir, fileName:fileName}));
        }
        return null;
    };

    // 检测是否支持本地存储
    b$.check_supportHtml5Storage = function(){
        try{
            return 'localStorage' in window && window['localStorage'] != null;
        }catch(e){
            return false;
        }
    };

    // 初始化默认的Manifest文件, callback 必须定义才有效
    b$.defaultManifest_key = 'js_defaultManifest_key';
    b$.defaultManifest = {};

    // 保存默认Manifest对象
    b$.saveDefaultManifest = function(newManifest){
        if(!b$.check_supportHtml5Storage()) return false;
        var obj = {manifest: newManifest || b$.defaultManifest};
        var encoded = $.toJSON(obj);
        window.localStorage.setItem(b$.defaultManifest_key, encoded);
        return true;
    };

    // 还原默认Manifest对象
    b$.revertDefaultManifest = function(){
        if(!b$.check_supportHtml5Storage()) return false;
        var encoded = window.localStorage.getItem(b$.defaultManifest_key);
        if(encoded != null){
            var obj = $.secureEvalJSON(encoded);
            b$.defaultManifest = obj.manifest;
        }

        return true;
    };



    window['BS'] = {};
    window['BS']['b$'] = b$;

})();


